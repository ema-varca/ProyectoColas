/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocolas;
import java.util.LinkedList;
import javax.swing.JOptionPane;

/**
 *
 * @author emanu
 */
public class Colas {
    
String nombre = " ";
    int mayor, menor = 0;

    LinkedList<String> cola1 = new LinkedList();
    LinkedList<String> cola2 = new LinkedList();
    LinkedList<String> cola3 = new LinkedList();
    LinkedList<String> cola4 = new LinkedList();

    public void cajero() {
        //String nombre1=" ";
        nombre = JOptionPane.showInputDialog("Ingrese su nombre");
        
        if (cola1.size()>cola2.size() && cola2.size()>cola3.size() && cola3.size()>cola4.size()) {//AVERIGUANDO CUAL ES EL MENOR
            
        } else if (cola2.size() < cola3.size()) {  //SI COLA 2 ES MENOR QUE COLA 3
            cola2.offer(nombre);
        } else if (cola3.size() < cola4.size()) {  //SI COLA 3 ES MENOR QUE COLA 4
            cola3.offer(nombre);
        }
        cola4.offer(nombre);
    }

    public void mostrar() {
        JOptionPane.showMessageDialog(null, "El tamaño de la fila del cajero 1 es.. " + cola1.size() + "\n "
                + "El tamaño de la fila del cajero 2 es.. " + cola2.size() + "\n "
                + "El tamaño de la fila del cajero 3 es.. " + cola3.size() + "\n "
                + "El tamaño de la fila del cajero 4 es.. " + cola4.size() + "\n ");
    }

    public void atender() {
        int selec = Integer.parseInt(JOptionPane.showInputDialog("Cual cajero va atender en este momento?"));
        switch (selec) {
            case 1:
                cola1.remove();
                break;
            case 2:
                cola2.remove();
                break;
            case 3:
                cola3.remove();
                break;
            case 4:
                cola4.remove();
                break;

            default:
        }
    }
}

