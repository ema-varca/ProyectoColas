/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocolas;

import javax.swing.JOptionPane;

/**
 *
 * @author emanu
 */
public class ProyectoColas {

public static void main(String[] args) {
        Colas colas = new Colas ();
        int selec;
        do {
             selec = Integer.parseInt(JOptionPane.showInputDialog("Menu de opciones \n"+
                    "1. Ingresar Datos \n"+
                    "2. Mostrar Personas en cada cajero \n"+
                    "3. Seleccionar cajero para atender\n"+
                    "4. Salir"));
            switch (selec) {
                
                case 1:
                    colas.cajero();
                                  
                    break;
                case 2:
                    colas.mostrar();
                    break;
                case 3:
                    colas.atender();
                    break;
                case 4:
                    System.out.println("Ud ha decidido salir");
                    break;
                default:
            }
        } while (selec != 4);

    }

}